#ifndef DG_TIMSACH_H
#define DG_TIMSACH_H

#include <QWidget>

namespace Ui {
class DG_TimSach;
}

class DG_TimSach : public QWidget
{
    Q_OBJECT

public:
    explicit DG_TimSach(QWidget *parent = 0);
    ~DG_TimSach();

    void setuserID_TS(QString str)
    {
        userID_TS = str;
    }

private slots:
    void on_pushButton_clicked();

    void on_tableView_activated(const QModelIndex &index);

    void on_pushButton_2_clicked();

private:
    Ui::DG_TimSach *ui;
    QString userID_TS;
};

#endif // DG_TIMSACH_H
