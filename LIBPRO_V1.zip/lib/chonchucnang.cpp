#include "chonchucnang.h"
#include "ui_chonchucnang.h"
#include "databaseconnect.h"

ChonChucNang::ChonChucNang(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChonChucNang)
{
    ui->setupUi(this);
}

ChonChucNang::~ChonChucNang()
{
    delete ui;
}

void ChonChucNang::showEvent(QShowEvent *event)
{
    QWidget::showEvent( event );
    connectDatabase conn;
    conn.openConnection();
    if (!conn.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối!","Vui lòng kiểm tra Database");
    }
    else {
        QSqlQuery query;
        query.exec("select Vai_tro from Taikhoan_Vaitro where Tai_khoan = '" +tendangnhap_CN+ "'");
        QSqlQueryModel* model = new QSqlQueryModel;
        model->setQuery(query);
        ui->comboBox->setModel(model);
    }
}

void ChonChucNang::on_pushButton_clicked()
{
    if(ui->comboBox->currentText()=="Độc giả")
    {
        this->close();
        docGia.setuserID(tendangnhap_CN);
        docGia.show();
    }
    if(ui->comboBox->currentText()=="Thủ thư")
    {
        this->close();
        thuThu.setthuThuID(tendangnhap_CN);
        thuThu.show();
    }
    if(ui->comboBox->currentText()=="Quản lý")
    {
        this->close();
        quanLy.settenDangNhap(tendangnhap_CN);
        quanLy.show();
    }
}
