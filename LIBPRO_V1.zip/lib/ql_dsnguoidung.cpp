#include "ql_dsnguoidung.h"
#include "ui_ql_dsnguoidung.h"
#include "databaseconnect.h"

QL_dsNguoiDung::QL_dsNguoiDung(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QL_dsNguoiDung)
{
    ui->setupUi(this);
}

QL_dsNguoiDung::~QL_dsNguoiDung()
{
    delete ui;
}

void QL_dsNguoiDung::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    QSqlQuery query1;
    query1.exec("select * from Nguoi_dung");
    QSqlQueryModel* databaseModel1 = new QSqlQueryModel;
    databaseModel1->setQuery(query1);
    databaseModel1->setHeaderData(0,Qt::Horizontal,tr("Họ và tên"));
    databaseModel1->setHeaderData(1,Qt::Horizontal,tr("Giới tính"));
    databaseModel1->setHeaderData(2,Qt::Horizontal,tr("CMND"));
    databaseModel1->setHeaderData(3,Qt::Horizontal,tr("Ngày sinh"));
    databaseModel1->setHeaderData(4,Qt::Horizontal,tr("Email"));
    databaseModel1->setHeaderData(5,Qt::Horizontal,tr("Số điện thoại"));

    ui->tableView->setModel(databaseModel1);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void QL_dsNguoiDung::on_pushButton_2_clicked()
{
    QSqlQuery query;

    //Tìm kiếm dựa trên lựa chọn
    QString str,s2,s3,s4,s5,s6,s7;

    if(ui->lineEdit->text() == ""){
        s2 = "";
    }
    else {
        s2 = "Ho_ten like '%" + ui->lineEdit->text() + "%' and ";
    }

    if(ui->lineEdit_2->text() == ""){
        s3 = "";
    }
    else {
        s3 = "Gioi_tinh like '%" + ui->lineEdit_2->text() + "%' and ";
    }

    if(ui->lineEdit_3->text() == ""){
        s4 = "";
    }
    else {
        s4 = "CMND like '%" + ui->lineEdit_3->text() + "%' and ";
    }

    if(ui->lineEdit_4->text() == ""){
        s5 = "";
    }
    else {
        s5 = "Ngay_sinh = '"+ui->lineEdit_4->text()+"' and ";
    }

    if(ui->lineEdit_5->text() == ""){
        s6 = "";
    }
    else {
        s6 = "Email like '%" + ui->lineEdit_5->text() + "%'";
    }
    if(ui->lineEdit_6->text() == ""){
        s6 = "";
    }
    else {
        s6 = "So_dien_thoai like '%" + ui->lineEdit_6->text() + "%'";
    }


    str = "select *from Nguoi_dung where " + s2 + s3 + s4 + s5 + s6 + s7;

    if (s7 == "")
    {
        str = str.left(str.length() - 5);  //Bỏ chuỗi " and "
    }

    query.exec(str);

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("Họ và tên"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("Giới tính"));
    databaseModel->setHeaderData(2,Qt::Horizontal,tr("CMND"));
    databaseModel->setHeaderData(3,Qt::Horizontal,tr("Ngày sinh"));
    databaseModel->setHeaderData(4,Qt::Horizontal,tr("Email"));
    databaseModel->setHeaderData(5,Qt::Horizontal,tr("Số điện thoại"));

    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void QL_dsNguoiDung::on_tableView_activated(const QModelIndex &index)
{
    QSqlQuery query;
    query.prepare("select Ho_ten,Gioi_tinh,CMND,Ngay_sinh,Email,So_dien_thoai from Nguoi_dung where CMND = :var");
    query.bindValue(":var",ui->tableView->model()->data(index).toString());
    query.exec();
    while (query.next()) {
        ui->lineEdit_15->setText(query.value(2).toString());
        ui->lineEdit_7->setText(query.value(0).toString());
        ui->lineEdit_8->setText(query.value(1).toString());
        ui->lineEdit_9->setText(query.value(2).toString());
        ui->lineEdit_10->setText(query.value(3).toString());
        ui->lineEdit_11->setText(query.value(4).toString());
        ui->lineEdit_12->setText(query.value(5).toString());
        ui->lineEdit_16->setText(query.value(2).toString());
    }
}

void QL_dsNguoiDung::on_pushButton_3_clicked()
{
    bool isCorrect;

    if(ui->lineEdit_15->text() == ""){
        QMessageBox::about(this,"Lỗi nhập!","Vui lòng nhập CMND sách cần chỉnh sửa!");
    }
    else{
            QSqlQuery editQry;


            if(ui->lineEdit_7->text() == "" && ui->lineEdit_8->text() == "" && ui->lineEdit_9->text() == "" && ui->lineEdit_10->text() == "" && ui->lineEdit_11->text() == "" && ui->lineEdit_12->text() == ""){
                QMessageBox::about(this,"Không được để trống!","Vui lòng nhập giá trị để update!");
            }

            if(ui->lineEdit_7->text()!=""){
              editQry.prepare("update Nguoi_dung set Ho_ten = :newname where CMND = :CMND'");
              editQry.bindValue(":newnname",ui->lineEdit_7->text());
              editQry.bindValue(":CMND",ui->lineEdit_15->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_8->text()!=""){
              editQry.prepare("update Nguoi_dung set Gioi_tinh = :newyear where CMND = :CMND");
              editQry.bindValue(":newyear",ui->lineEdit_8->text());
              editQry.bindValue(":CMND",ui->lineEdit_15->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_10->text()!=""){
              editQry.prepare("update Nguoi_dung set Ngay_sinh = :newdate where CMND = :CMND");
              editQry.bindValue(":newdate",ui->lineEdit_10->text());
              editQry.bindValue(":CMND",ui->lineEdit_15->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_11->text()!=""){
              editQry.prepare("update Nguoi_dung set Email = :newemail where CMND = :CMND");
              editQry.bindValue(":newemail",ui->lineEdit_11->text());
              editQry.bindValue(":CMND",ui->lineEdit_15->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_12->text()!=""){
              editQry.prepare("update Nguoi_dung set So_dien_thoai = :newsdt where CMND = :CMND");
              editQry.bindValue(":newsdt",ui->lineEdit_12->text());
              editQry.bindValue(":CMND",ui->lineEdit_15->text());
              isCorrect = editQry.exec();
            }

            //CMND được cập nhật cuối cùng để không làm sai giá trị CMND được dùng để đối chiếu ở các giá trị update trên
            if(ui->lineEdit_9->text()!=""){
              editQry.prepare("update Nguoi_dung set CMND = :newCMND where CMND = :CMND");
              editQry.bindValue(":newCMND",ui->lineEdit_9->text());
              editQry.bindValue(":CMND",ui->lineEdit_15->text());
              isCorrect= editQry.exec();
            }
    }


    if(isCorrect){
        QMessageBox::about(this,"Update thành công","Đã update dữ liệu trong database!");
    }
    else if (ui->lineEdit->text() != ""){
        QMessageBox::about(this,"Lỗi!","Vui lòng kiểm tra lại dữ liệu nhập vào!");
    }
}

void QL_dsNguoiDung::on_pushButton_clicked()
{
    QSqlQuery removeQry;
    removeQry.prepare("delete from Nguoi_dung where CMND = :CMND");
    removeQry.bindValue(":CMND",ui->lineEdit_16->text());

    bool isRemoved =removeQry.exec();

    if(isRemoved){
        QMessageBox::about(this,"Xóa thành công!","Đã xóa dữ liệu khỏi database.");
    }
    else{
        QMessageBox::about(this,"Lỗi!","Nhập sai CMND! Vui lòng kiểm tra lại.");
    }
}
