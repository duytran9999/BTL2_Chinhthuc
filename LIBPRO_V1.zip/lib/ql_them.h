#ifndef QL_THEM_H
#define QL_THEM_H

#include <QWidget>

namespace Ui {
class QL_Them;
}

class QL_Them : public QWidget
{
    Q_OBJECT

public:
    explicit QL_Them(QWidget *parent = 0);
    ~QL_Them();

private slots:
    void on_pushButton_clicked();

private:
    Ui::QL_Them *ui;
};

#endif // QL_THEM_H
