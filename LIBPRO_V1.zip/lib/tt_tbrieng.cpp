#include "tt_tbrieng.h"
#include "ui_tt_tbrieng.h"

TT_TBRieng::TT_TBRieng(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TT_TBRieng)
{
    ui->setupUi(this);
}

TT_TBRieng::~TT_TBRieng()
{
    delete ui;
}

void TT_TBRieng::on_pushButton_clicked()
{
    QSqlQuery qry;
    qry.exec("select * from Tai_khoan where Ten_dang_nhap='"+ui->lineEdit->text() +"'" );
    int count=0;
    while(qry.next())
    {
        count ++;
    }
    if(count!=1)
        QMessageBox::critical(this,"Thất bại","Không tồn tại tài khoản này");
    else
    {
        qry.prepare("insert into Thong_bao_rieng values (:id,:thongbao)");
        qry.bindValue(":id",ui->lineEdit->text());
        qry.bindValue(":thongbao",ui->textEdit->toPlainText());
        bool written = qry.exec();
        if(written){
            QMessageBox::about(this,"Thành công!","Đã gửi thông báo.");
            //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
            ui->textEdit->setText("");
        }
        else{
            QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào");
        }
    }
}
