#ifndef DANGKIW_H
#define DANGKIW_H

#include <QWidget>
#include "dangki.h"
#include "ql_themtk.h"

namespace Ui {
class DangKiW;
}

class DangKiW : public QWidget
{
    Q_OBJECT

public:
    explicit DangKiW(QWidget *parent = 0);
    ~DangKiW();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::DangKiW *ui;
    dangki *dangKi = new dangki;
    QL_ThemTK *them = new QL_ThemTK;
};

#endif // DANGKIW_H
