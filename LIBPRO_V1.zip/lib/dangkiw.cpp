#include "dangkiw.h"
#include "ui_dangkiw.h"

DangKiW::DangKiW(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DangKiW)
{
    ui->setupUi(this);
}

DangKiW::~DangKiW()
{
    delete ui;
}

void DangKiW::on_pushButton_2_clicked()
{
    this->close();
    dangKi->show();
}

void DangKiW::on_pushButton_clicked()
{
    this->close();
    them->show();
}
