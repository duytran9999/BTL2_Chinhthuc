#include "quanly.h"
#include "ui_quanly.h"
#include "chonchucnang.h"
#include "trangchu.h"

QuanLy::QuanLy(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QuanLy)
{
    ui->setupUi(this);
}

QuanLy::~QuanLy()
{
    delete ui;
}

void QuanLy::on_pushButton_9_clicked()
{
    doiMK.settendangnhap(tenDangNhap);
    doiMK.show();
}

void QuanLy::on_pushButton_10_clicked()
{
    this->hide();
    ChonChucNang *chonCN = new ChonChucNang;
    chonCN->settendangnhap_CN(tenDangNhap);
    chonCN->show();
}

void QuanLy::on_pushButton_clicked()
{
    add.show();
}

void QuanLy::on_pushButton_2_clicked()
{
    danhSach.show();
}

void QuanLy::on_pushButton_3_clicked()
{
    themTK.show();
}

void QuanLy::on_pushButton_4_clicked()
{
    moKhoa.show();
}

void QuanLy::on_pushButton_5_clicked()
{
    dS.show();
}

void QuanLy::on_pushButton_11_clicked()
{
    this->close();
    trangchu *main = new trangchu;
    main->show();
}
