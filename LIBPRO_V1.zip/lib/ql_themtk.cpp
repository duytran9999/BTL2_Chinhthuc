#include "ql_themtk.h"
#include "ui_ql_themtk.h"
#include "databaseconnect.h"

QL_ThemTK::QL_ThemTK(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QL_ThemTK)
{
    ui->setupUi(this);
}

QL_ThemTK::~QL_ThemTK()
{
    delete ui;
}

void QL_ThemTK::on_pushButton_clicked()
{
    QSqlQuery qry,qry1;
    qry.exec("select * from Tai_khoan where Ten_dang_nhap='"+ui->lineEdit_2->text() +"'" );
    int count=0;
    while(qry.next())
    {
        count ++;
    }
    qry1.exec("select * from Nguoi_dung where CMND='"+ui->lineEdit->text() +"'" );
    int count2=0;
    while(qry1.next())
    {
        count2++;
    }
    if(ui->lineEdit->text()=="" || ui->lineEdit_2->text()=="" || ui->lineEdit_3->text()==""){
        //Kiem tra hang null
        QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else if(count2 != 1)
    {
        QMessageBox::about(this,"Lỗi nhập dữ liệu!","CMND không tồn tại.");
    }
    else if(count == 1)
    {
        QMessageBox::about(this,"Lỗi nhập dữ liệu!","Tài khoản đã tồn tại.");
    }
    else
    {
        //Them du lieu vao database
        QSqlQuery writeQry;
        QString tendangnhap, matkhau, CMND;

        CMND = ui->lineEdit->text();
        tendangnhap = ui->lineEdit_2->text();
        matkhau = ui->lineEdit_3->text();

        writeQry.exec("insert into NguoiDung_TK values ('"+tendangnhap+"','"+CMND+"')");
        writeQry.exec("insert into Tai_khoan(Ten_dang_nhap,Mat_khau) values ('"+tendangnhap+"','"+matkhau+"')");
        if(ui->radioButton->isChecked())
        {
            writeQry.exec("insert into Taikhoan_Vaitro values ('"+tendangnhap+"','Độc giả')");
        }
        if(ui->radioButton_2->isChecked())
        {
            writeQry.exec("insert into Taikhoan_Vaitro values ('"+tendangnhap+"','Thủ thư')");
        }
        if(ui->radioButton_3->isChecked())
        {
            writeQry.exec("insert into Taikhoan_Vaitro values ('"+tendangnhap+"','Quản lý')");
        }
        QMessageBox::about(this,"Thành công","Đã thêm tài khoản vào database");

    }
}
