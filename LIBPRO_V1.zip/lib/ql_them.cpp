#include "ql_them.h"
#include "ui_ql_them.h"
#include "databaseconnect.h"

QL_Them::QL_Them(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QL_Them)
{
    ui->setupUi(this);
}

QL_Them::~QL_Them()
{
    delete ui;
}

void QL_Them::on_pushButton_clicked()
{
    QString gioiTinh,ngaySinh;
    if(!ui->radioButton->isChecked() && !ui->radioButton_2->isChecked())
        QMessageBox::critical(this,"Lỗi","Vui lòng kiểm tra dữ liệu nhập");
    else if(ui->radioButton->isChecked())
        gioiTinh = "Nam";
    else {
        gioiTinh = "Nữ";
    }
    ngaySinh = ui->comboBox_ngay->currentText() + "/" + ui->comboBox_thang->currentText()+"/" + ui->comboBox_nam->currentText();
    QSqlQuery qry;
    qry.exec("select * from Nguoi_dung where CMND='"+ui->lineEdit_2->text() +"'" );
    int count=0;
    while(qry.next())
    {
        count ++;
    }
    if(count==1)
        QMessageBox::critical(this,"Lỗi","CMND đã tồn tại");
    else {
        qry.prepare("insert into Nguoi_dung values(:ten,:gioitinh,:CMND,:ngaysinh,:email,:dienthoai)");
        qry.bindValue(":ten",ui->lineEdit->text());
        qry.bindValue(":gioitinh",gioiTinh);
        qry.bindValue(":ngaysinh",ngaySinh);
        qry.bindValue(":CMND",ui->lineEdit_2->text());
        qry.bindValue(":email",ui->lineEdit_3->text());
        qry.bindValue(":dienthoai",ui->lineEdit_4->text());
        qry.exec();
        QMessageBox::about(this,"Thành công","Đã thêm dữ liệu vào database");
    }

}
