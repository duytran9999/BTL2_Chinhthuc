#ifndef QL_DSTAIKHOAN_H
#define QL_DSTAIKHOAN_H

#include <QWidget>

namespace Ui {
class QL_DSTaiKhoan;
}

class QL_DSTaiKhoan : public QWidget
{
    Q_OBJECT

public:
    explicit QL_DSTaiKhoan(QWidget *parent = 0);
    ~QL_DSTaiKhoan();

private slots:
    void on_pushButton_clicked();

private:
    Ui::QL_DSTaiKhoan *ui;
};

#endif // QL_DSTAIKHOAN_H
