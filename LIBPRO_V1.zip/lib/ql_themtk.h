#ifndef QL_THEMTK_H
#define QL_THEMTK_H

#include <QWidget>

namespace Ui {
class QL_ThemTK;
}

class QL_ThemTK : public QWidget
{
    Q_OBJECT

public:
    explicit QL_ThemTK(QWidget *parent = 0);
    ~QL_ThemTK();

private slots:
    void on_pushButton_clicked();

private:
    Ui::QL_ThemTK *ui;
};

#endif // QL_THEMTK_H
