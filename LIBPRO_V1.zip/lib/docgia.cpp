#include "docgia.h"
#include "ui_docgia.h"
#include "chonchucnang.h"
#include "trangchu.h"

DocGia::DocGia(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DocGia)
{
    ui->setupUi(this);
}

DocGia::~DocGia()
{
    delete ui;
}

void DocGia::showEvent(QShowEvent *event)
{
    QWidget::showEvent( event );

    //Bảng sách mới
    QSqlQuery query1;
    query1.exec("select * from CSBooks where Nam = (select MAX(Nam) from CSBooks)");
    QSqlQueryModel* databaseModel1 = new QSqlQueryModel;
    databaseModel1->setQuery(query1);
    databaseModel1->setHeaderData(0,Qt::Horizontal,tr("ID sách"));
    databaseModel1->setHeaderData(1,Qt::Horizontal,tr("Tên sách"));
    databaseModel1->setHeaderData(2,Qt::Horizontal,tr("Tác giả"));
    databaseModel1->setHeaderData(3,Qt::Horizontal,tr("Thể loại"));
    databaseModel1->setHeaderData(4,Qt::Horizontal,tr("Năm xuất bản"));
    databaseModel1->setHeaderData(5,Qt::Horizontal,tr("Số lượng"));

    ui->tableView_2->setModel(databaseModel1);
    ui->tableView_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    //Thông báo chung
    QSqlQuery query;
    query.exec("select * from Thong_bao_chung");
    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    ui->tableView_3->setModel(databaseModel);
    ui->tableView_3->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView_3->horizontalHeader()->hide();

    //Thông báo riêng
    QSqlQuery query2;
    query2.exec("select Noi_dung from Thong_bao_rieng where ID_docgia = '"+userID+"'");
    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel2 = new QSqlQueryModel;
    databaseModel2->setQuery(query2);
    ui->tableView->setModel(databaseModel2);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->horizontalHeader()->hide();

}

void DocGia::on_pushButton_clicked()
{
    connectDatabase conn;
    conn.openConnection();
    if(!conn.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        dg_timSach.setuserID_TS(userID);
        dg_timSach.show();
    }
}

void DocGia::on_pushButton_7_clicked()
{
    this->close();
    ChonChucNang *chonCN = new ChonChucNang;
    chonCN->settendangnhap_CN(userID);
    chonCN->show();
}

void DocGia::on_pushButton_6_clicked()
{
    connectDatabase conn;
    conn.openConnection();
    if(!conn.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        dg_traSach.setdocgiaID_PM(userID);
        dg_traSach.show();
    }
}

void DocGia::on_pushButton_8_clicked()
{
    doiMK.settendangnhap(userID);
    doiMK.show();
}

void DocGia::on_pushButton_4_clicked()
{
    this->close();
    trangchu *main = new trangchu;
    main->show();
}
