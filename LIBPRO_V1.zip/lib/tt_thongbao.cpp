#include "tt_thongbao.h"
#include "ui_tt_thongbao.h"

TT_ThongBao::TT_ThongBao(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TT_ThongBao)
{
    ui->setupUi(this);
}

TT_ThongBao::~TT_ThongBao()
{
    delete ui;
}

void TT_ThongBao::on_pushButton_clicked()
{
    tBC.show();
}

void TT_ThongBao::on_pushButton_2_clicked()
{
    tBR.show();
}
