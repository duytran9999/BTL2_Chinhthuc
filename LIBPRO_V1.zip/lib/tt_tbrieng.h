#ifndef TT_TBRIENG_H
#define TT_TBRIENG_H

#include <QWidget>
#include "databaseconnect.h"

namespace Ui {
class TT_TBRieng;
}

class TT_TBRieng : public QWidget
{
    Q_OBJECT

public:
    explicit TT_TBRieng(QWidget *parent = 0);
    ~TT_TBRieng();

private slots:
    void on_pushButton_clicked();

private:
    Ui::TT_TBRieng *ui;
};

#endif // TT_TBRIENG_H
