#ifndef MUONQUAHAN_H
#define MUONQUAHAN_H

#include <QWidget>

namespace Ui {
class MuonQuaHan;
}

class MuonQuaHan : public QWidget
{
    Q_OBJECT

public:
    explicit MuonQuaHan(QWidget *parent = 0);
    ~MuonQuaHan();

private slots:
    void showEvent(QShowEvent *event);

    void on_pushButton_clicked();

private:
    Ui::MuonQuaHan *ui;
};

#endif // MUONQUAHAN_H
