#ifndef QL_MOKHOA_H
#define QL_MOKHOA_H

#include <QWidget>

namespace Ui {
class QL_MoKhoa;
}

class QL_MoKhoa : public QWidget
{
    Q_OBJECT

public:
    explicit QL_MoKhoa(QWidget *parent = 0);
    ~QL_MoKhoa();

private slots:
    void showEvent(QShowEvent *event);

    void on_tableView_activated(const QModelIndex &index);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::QL_MoKhoa *ui;
};

#endif // QL_MOKHOA_H
