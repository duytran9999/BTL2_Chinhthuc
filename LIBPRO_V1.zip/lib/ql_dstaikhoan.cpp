#include "ql_dstaikhoan.h"
#include "ui_ql_dstaikhoan.h"
#include "databaseconnect.h"

QL_DSTaiKhoan::QL_DSTaiKhoan(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QL_DSTaiKhoan)
{
    ui->setupUi(this);
}

QL_DSTaiKhoan::~QL_DSTaiKhoan()
{
    delete ui;
}

void QL_DSTaiKhoan::on_pushButton_clicked()
{
    QSqlQuery query;

    //Tìm kiếm dựa trên lựa chọn
    QString str,s2,s3;

    if(ui->lineEdit->text() == ""){
        s2 = "";
    }
    else {
        s2 = "ID_sach like '%" + ui->lineEdit->text() + "%' and ";
    }

    if(ui->lineEdit_2->text() == ""){
        s3 = "";
    }
    else {
        s3 = "Ten_sach like '%" + ui->lineEdit_2->text() + "%' and ";
    }


    str = "select *from NguoiDung_TK where " + s2 + s3;

    if (s3 == "")
    {
        str = str.left(str.length() - 5);  //Bỏ chuỗi " and "
    }

    query.exec(str);

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("Tên đăng nhập"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("CMND"));

    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}
