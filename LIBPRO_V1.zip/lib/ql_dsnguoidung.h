#ifndef QL_DSNGUOIDUNG_H
#define QL_DSNGUOIDUNG_H

#include <QWidget>

namespace Ui {
class QL_dsNguoiDung;
}

class QL_dsNguoiDung : public QWidget
{
    Q_OBJECT

public:
    explicit QL_dsNguoiDung(QWidget *parent = 0);
    ~QL_dsNguoiDung();

private slots:
    void QL_dsNguoiDung::showEvent(QShowEvent *event);

    void on_pushButton_2_clicked();

    void on_tableView_activated(const QModelIndex &index);

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

private:
    Ui::QL_dsNguoiDung *ui;
};

#endif // QL_DSNGUOIDUNG_H
