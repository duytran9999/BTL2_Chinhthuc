#include "muonquahan.h"
#include "ui_muonquahan.h"
#include "thuthuwindow.h"

MuonQuaHan::MuonQuaHan(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MuonQuaHan)
{
    ui->setupUi(this);
}

MuonQuaHan::~MuonQuaHan()
{
    delete ui;
}

void MuonQuaHan::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    QSqlQuery query;
    query.exec("select ID_phieu_muon,CAST((julianday('now') - julianday(Ngay_muon)) AS INTEGER) from Muon_sach where julianday('now') - julianday(Ngay_muon) > 10 and Nop_tien_phat = 0");

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("ID phiếu mượn"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("Số ngày trễ"));
    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void MuonQuaHan::on_pushButton_clicked()
{
    QString str = "Phiếu mượn sách của bạn đã quá hạn. Vui lòng trả sách và nộp tiền phạt. Nếu trễ quá 7 ngày. Tài khoản của bạn sẽ bị khóa";
    QSqlQuery qry;
    qry.exec("insert into Thong_bao_rieng values ((select ID_user from Muon_sach where julianday('now') - julianday(Ngay_muon) > 10 and Nop_tien_phat = 0),'"+str+"')");
    QMessageBox::about(this,"Thành công","Đã gửi thông báo");
}
