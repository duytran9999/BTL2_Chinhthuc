#ifndef TT_THONGBAO_H
#define TT_THONGBAO_H

#include <QWidget>
#include "databaseconnect.h"
#include "tt_tbchung.h"
#include "tt_tbrieng.h"

namespace Ui {
class TT_ThongBao;
}

class TT_ThongBao : public QWidget
{
    Q_OBJECT

public:
    explicit TT_ThongBao(QWidget *parent = 0);
    ~TT_ThongBao();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::TT_ThongBao *ui;
    TT_TBChung tBC;
    TT_TBRieng tBR;
};

#endif // TT_THONGBAO_H
