#include "ql_mokhoa.h"
#include "ui_ql_mokhoa.h"
#include "databaseconnect.h"

QL_MoKhoa::QL_MoKhoa(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QL_MoKhoa)
{
    ui->setupUi(this);
}

QL_MoKhoa::~QL_MoKhoa()
{
    delete ui;
}

void QL_MoKhoa::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);

    QSqlQuery query1;
    query1.exec("select Ten_dang_nhap,Tinh_trang from Tai_khoan");
    QSqlQueryModel* databaseModel1 = new QSqlQueryModel;
    databaseModel1->setQuery(query1);
    databaseModel1->setHeaderData(0,Qt::Horizontal,tr("Tên đăng nhập"));
    databaseModel1->setHeaderData(1,Qt::Horizontal,tr("Tình trạng"));

    ui->tableView->setModel(databaseModel1);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

}

void QL_MoKhoa::on_tableView_activated(const QModelIndex &index)
{
    QSqlQuery query;
    query.prepare("select Ten_dang_nhap from Tai_khoan where Ten_dang_nhap = :var");
    query.bindValue(":var",ui->tableView->model()->data(index).toString());
    query.exec();
    while (query.next()) {
        ui->lineEdit->setText(query.value(0).toString());
    }
}

void QL_MoKhoa::on_pushButton_clicked()
{
    QSqlQuery query;
    query.exec("update Tai_khoan set Tinh_trang = 1 where Ten_dang_nhap = '"+ui->lineEdit->text()+"'");
    QMessageBox::about(this,"Thành công","Đã mở tài khoản");
}

void QL_MoKhoa::on_pushButton_2_clicked()
{
    QSqlQuery query;
    query.exec("update Tai_khoan set Tinh_trang = 0 where Ten_dang_nhap = '"+ui->lineEdit->text()+"'");
    QMessageBox::about(this,"Thành công","Đã khóa tài khoản");
}
