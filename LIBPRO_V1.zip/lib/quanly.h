#ifndef QUANLY_H
#define QUANLY_H

#include <QWidget>
#include "databaseconnect.h"
#include "doimk.h"
#include "ql_them.h"
#include "ql_dsnguoidung.h"
#include "ql_themtk.h"
#include "ql_mokhoa.h"
#include "ql_dstaikhoan.h"

namespace Ui {
class QuanLy;
}

class QuanLy : public QWidget
{
    Q_OBJECT

public:
    explicit QuanLy(QWidget *parent = 0);
    ~QuanLy();

    void settenDangNhap(QString str)
    {
        tenDangNhap = str;
    }

private slots:
    void on_pushButton_9_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_11_clicked();

private:
    Ui::QuanLy *ui;
    QString tenDangNhap;
    DoiMK doiMK;
    QL_Them add;
    QL_dsNguoiDung danhSach;
    QL_ThemTK themTK;
    QL_MoKhoa moKhoa;
    QL_DSTaiKhoan dS;

};

#endif // QUANLY_H
