#include "docgia.h"
#include "ui_docgia.h"

DocGia::DocGia(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DocGia)
{
    ui->setupUi(this);
}

DocGia::~DocGia()
{
    delete ui;
}

void DocGia::on_pushButton_clicked()
{
    connectDatabase conn;
    conn.openConnection();
    if(!conn.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        dg_timSach.setuserID_TS(userID);
        dg_timSach.show();
    }
}

void DocGia::on_pushButton_7_clicked()
{

}

void DocGia::on_pushButton_6_clicked()
{
    connectDatabase conn;
    conn.openConnection();
    if(!conn.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        //DG_TimSach dg_timSach;
        dg_traSach.show();
    }
}
