#include "removebook.h"
#include "ui_removebook.h"
#include "thuthuwindow.h"

RemoveBook::RemoveBook(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RemoveBook)
{
    ui->setupUi(this);
}

RemoveBook::~RemoveBook()
{
    delete ui;
}

void RemoveBook::on_pushButton_2_clicked()
{
    this->close();
}

void RemoveBook::on_pushButton_clicked()
{
    QSqlQuery removeQry;
    //Kiem tra du lieu nhap vao khac null
    if(ui->txt_ID->text() == ""){
    QMessageBox::about(this,"Lỗi nhập!","Vui lòng nhập vào ID của sách");
    }
    //Xoa sach khoi database
    else {
        removeQry.prepare("delete from CSBooks where ID_sach = :bookid");
        removeQry.bindValue(":bookid",ui->txt_ID->text());
    }

    bool isRemoved =removeQry.exec();

    if(isRemoved){
        QMessageBox::about(this,"Xóa thành công!","Đã xóa dữ liệu khỏi database.");
        //Đua dong nhap ve gia tri null
        ui->txt_ID->setText("");
    }
    else{
        QMessageBox::about(this,"Lỗi!","Nhập sai ID! Vui lòng kiểm tra lại.");
    }

}
