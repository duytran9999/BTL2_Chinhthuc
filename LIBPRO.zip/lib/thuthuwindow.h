#ifndef THUTHUWINDOW_H
#define THUTHUWINDOW_H

#include <QWidget>
#include "databaseconnect.h"
#include "addbook.h"
#include "removebook.h"
#include "editbook.h"
#include "findbook.h"
#include "muonsach.h"
#include "trasach.h"
#include "muonquahan.h"

namespace Ui {
class ThuThuWindow;
}

class ThuThuWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ThuThuWindow(QWidget *parent = 0);
    ~ThuThuWindow();

    void setthuThuID(QString str)
    {
        thuThuID = str;
    }

private slots:
    void on_pushButton_2_clicked();     //Thêm sách

    void on_pushButton_4_clicked();     //Xóa sách

    void on_pushButton_3_clicked();     //Chỉnh sửa sách

    void on_pushButton_clicked();       //Tìm sách

    void on_pushButton_5_clicked();     //Mượn sách

    void on_pushButton_6_clicked();     //Trả sách

    void on_pushButton_7_clicked();     //Xử lý trễ hạn

    void on_pushButton_8_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_9_clicked();

private:
    Ui::ThuThuWindow *ui;
    QString thuThuID;
    FindBook timSach;
    addBook themSach;
    EditBook chinhSua;
    RemoveBook xoaSach;
    MuonSach muonSach;
    TraSach traSach;
    MuonQuaHan muonQuaHan;
};

#endif // THUTHUWINDOW_H
