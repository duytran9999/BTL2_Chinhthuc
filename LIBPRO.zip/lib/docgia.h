#ifndef DOCGIA_H
#define DOCGIA_H

#include <QWidget>
#include "dg_timsach.h"
#include "dg_trasach.h"
#include "databaseconnect.h"

namespace Ui {
class DocGia;
}

class DocGia : public QWidget
{
    Q_OBJECT

public:
    explicit DocGia(QWidget *parent = 0);
    ~DocGia();

    void setuserID(QString str){
        userID = str;
    }

private slots:
    void on_pushButton_clicked();               //Tìm sách

    void on_pushButton_7_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::DocGia *ui;
    QString userID;
    DG_TimSach dg_timSach;
    DG_TraSach dg_traSach;
};

#endif // DOCGIA_H
