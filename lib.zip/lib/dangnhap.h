#ifndef DANGNHAP_H
#define DANGNHAP_H

#include <QDialog>
#include <QMessageBox>
#include <QMainWindow>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include <QDebug>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <string>
#include <QString>
#include <QComboBox>
#include "thuthuwindow.h"
#include "docgia.h"

namespace Ui {
class dangnhap;
}

class dangnhap : public QDialog
{
    Q_OBJECT

public:
    explicit dangnhap(QWidget *parent = 0);
    ~dangnhap();

private slots:
    void on_pushButton_dangnhap_clicked();

private:
    Ui::dangnhap *ui;
    ThuThuWindow thuThu;
    DocGia docGia;
};

#endif // DANGNHAP_H
