#include "dg_trasach.h"
#include "ui_dg_trasach.h"
#include "docgia.h"

DG_TraSach::DG_TraSach(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DG_TraSach)
{
    ui->setupUi(this);
}

DG_TraSach::~DG_TraSach()
{
    delete ui;
}
