#include "trasach.h"
#include "ui_trasach.h"
#include "thuthuwindow.h"

TraSach::TraSach(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TraSach)
{
    ui->setupUi(this);
}

TraSach::~TraSach()
{
    delete ui;
}

void TraSach::on_pushButton_2_clicked()
{
    //Đưa các dòng nhập về giá trị Null
    ui->lineEdit->setText("");
    ui->lineEdit_2->setText("");
    ui->lineEdit_3->setText("");

    //Đóng cửa sổ
    this->close();
}

void TraSach::on_pushButton_clicked()
{


    if(ui->lineEdit->text()=="" || ui->lineEdit_2->text()=="" || ui->lineEdit_3->text()=="" ){

            //Kiem tra hang null
            QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else {
        QSqlQuery editQry;
        editQry.prepare("update Muon_sach set Ngay_tra = :newdate where ID_user =:userid and ID_sach = :bookid");
        editQry.bindValue(":userid",ui->lineEdit->text());
        editQry.bindValue(":bookid",ui->lineEdit_2->text());
        editQry.bindValue(":newdate",ui->lineEdit_3->text());
        bool isCorrect = editQry.exec();
        if(isCorrect){
            QMessageBox::about(this,"Update thành công","Đã update dữ liệu trong database!");

            //Đưa các dòng nhập về giá trị Null
            ui->lineEdit->setText("");
            ui->lineEdit_2->setText("");
            ui->lineEdit_3->setText("");
        }
        else {
            QMessageBox::about(this,"Lỗi!","Vui lòng kiểm tra lại dữ liệu nhập vào!");
        }
    }
}

void TraSach::on_pushButton_3_clicked()
{
    QSqlQuery query;
    query.exec("select ID_user,ID_sach,Ngay_muon,Han_tra from Muon_sach where Ngay_tra is NULL");

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("ID độc giả"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("ID sách"));
    databaseModel->setHeaderData(2,Qt::Horizontal,tr("Ngày mượn"));
    databaseModel->setHeaderData(3,Qt::Horizontal,tr("Hạn trả"));
    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void TraSach::on_tableView_activated(const QModelIndex &index)
{
    QSqlQuery query;
    query.prepare("select ID_user,ID_sach from Muon_sach where ID_user = :var or ID_sach = :var");
    query.bindValue(":var",ui->tableView->model()->data(index).toString());
    query.exec();
    while (query.next()) {
        ui->lineEdit->setText(query.value(0).toString());
        ui->lineEdit_2->setText(query.value(1).toString());
    }
}
