#include "muonsach.h"
#include "ui_muonsach.h"
#include "thuthuwindow.h"

MuonSach::MuonSach(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MuonSach)
{
    ui->setupUi(this);
}

MuonSach::~MuonSach()
{
    delete ui;
}

void MuonSach::on_pushButton_2_clicked()
{
    //Dua dong nhap ve gia tri null
    ui->lineEdit->setText("");

    this->close();
}

void MuonSach::on_pushButton_clicked()
{
    if(ui->txt_ID_thuthu->text()=="" || ui->lineEdit->text()=="" ){

            //Kiem tra hang null
            QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else {
        QSqlQuery writeQry;

        writeQry.prepare("update Muon_sach set Ngay_muon = date('now'), Cho_phep = 1, ID_thuthu = :userid where ID_phieu_muon = :idphieu");
        writeQry.bindValue(":userid",ui->txt_ID_thuthu->text());
        writeQry.bindValue(":idphieu",ui->lineEdit->text());

        bool written = writeQry.exec();
        if(written){
            QMessageBox::about(this,"Ghi nhận thành công!","Đồng ý cho mượn sách");

            //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
            ui->lineEdit->setText("");

        }
        else{
            QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào và kết nối database ");
        }

    }
}

void MuonSach::on_pushButton_4_clicked()
{
    QSqlQuery query;
    query.exec("select ID_phieu_muon,ID_user,ID_sach,So_luong from Muon_sach where Cho_phep is NULL");

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("ID phiếu mượn"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("ID độc giả"));
    databaseModel->setHeaderData(2,Qt::Horizontal,tr("ID sách"));
    databaseModel->setHeaderData(3,Qt::Horizontal,tr("Số lượng"));
    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void MuonSach::on_tableView_activated(const QModelIndex &index)
{
    QSqlQuery query;
    query.prepare("select ID_phieu_muon from Muon_sach where ID_phieu_muon = :var");
    query.bindValue(":var",ui->tableView->model()->data(index).toString());
    query.exec();
    while (query.next()) {
        ui->lineEdit->setText(query.value(0).toString());
    }
}

void MuonSach::on_pushButton_3_clicked()
{
    if(ui->txt_ID_thuthu->text()=="" || ui->lineEdit->text()=="" ){

            //Kiem tra hang null
            QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else {
        QSqlQuery writeQry;

        writeQry.prepare("update Muon_sach set Cho_phep = 0, ID_thuthu = :userid where ID_phieu_muon = :idphieu");
        writeQry.bindValue(":userid",ui->txt_ID_thuthu->text());
        writeQry.bindValue(":idphieu",ui->lineEdit->text());

        bool written = writeQry.exec();
        if(written){
            QMessageBox::about(this,"Ghi nhận thành công!","Từ chối cho mượn sách");

            //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
            ui->lineEdit->setText("");

        }
        else{
            QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào và kết nối database ");
        }

    }
}
