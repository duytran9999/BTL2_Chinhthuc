#ifndef DG_TRASACH_H
#define DG_TRASACH_H

#include <QWidget>

namespace Ui {
class DG_TraSach;
}

class DG_TraSach : public QWidget
{
    Q_OBJECT

public:
    explicit DG_TraSach(QWidget *parent = 0);
    ~DG_TraSach();

private:
    Ui::DG_TraSach *ui;
};

#endif // DG_TRASACH_H
