/********************************************************************************
** Form generated from reading UI file 'dangki.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DANGKI_H
#define UI_DANGKI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dangki
{
public:
    QPushButton *pushButton_dangki;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLineEdit *lineEdit_hoten;
    QHBoxLayout *horizontalLayout;
    QRadioButton *radioButton_nam;
    QRadioButton *radioButton_nu;
    QLineEdit *lineEdit_tendangnhap;
    QLineEdit *lineEdit_matkhau;
    QLabel *label_13;
    QLineEdit *lineEdit_xnmatkhau;
    QLineEdit *lineEdit_mail;
    QLineEdit *lineEdit_xnmail;
    QLineEdit *lineEdit_CMND;
    QHBoxLayout *horizontalLayout_2;
    QComboBox *comboBox_ngay;
    QComboBox *comboBox_thang;
    QComboBox *comboBox_nam;
    QLineEdit *lineEdit_sdt;
    QHBoxLayout *horizontalLayout_3;
    QComboBox *comboBox_chucvu;
    QLineEdit *lineEdit_machucvu;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_10;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_14;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_5;
    QLabel *label_2;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_xnmatkhau;
    QLabel *label_matkhau_1;
    QLabel *label_mail_1;
    QLabel *label_tendangnhap_1;

    void setupUi(QDialog *dangki)
    {
        if (dangki->objectName().isEmpty())
            dangki->setObjectName(QStringLiteral("dangki"));
        dangki->resize(902, 432);
        pushButton_dangki = new QPushButton(dangki);
        pushButton_dangki->setObjectName(QStringLiteral("pushButton_dangki"));
        pushButton_dangki->setGeometry(QRect(480, 400, 93, 28));
        verticalLayoutWidget = new QWidget(dangki);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(380, 20, 331, 371));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        lineEdit_hoten = new QLineEdit(verticalLayoutWidget);
        lineEdit_hoten->setObjectName(QStringLiteral("lineEdit_hoten"));

        verticalLayout->addWidget(lineEdit_hoten);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        radioButton_nam = new QRadioButton(verticalLayoutWidget);
        radioButton_nam->setObjectName(QStringLiteral("radioButton_nam"));

        horizontalLayout->addWidget(radioButton_nam);

        radioButton_nu = new QRadioButton(verticalLayoutWidget);
        radioButton_nu->setObjectName(QStringLiteral("radioButton_nu"));

        horizontalLayout->addWidget(radioButton_nu);


        verticalLayout->addLayout(horizontalLayout);

        lineEdit_tendangnhap = new QLineEdit(verticalLayoutWidget);
        lineEdit_tendangnhap->setObjectName(QStringLiteral("lineEdit_tendangnhap"));

        verticalLayout->addWidget(lineEdit_tendangnhap);

        lineEdit_matkhau = new QLineEdit(verticalLayoutWidget);
        lineEdit_matkhau->setObjectName(QStringLiteral("lineEdit_matkhau"));

        verticalLayout->addWidget(lineEdit_matkhau);

        label_13 = new QLabel(verticalLayoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        verticalLayout->addWidget(label_13);

        lineEdit_xnmatkhau = new QLineEdit(verticalLayoutWidget);
        lineEdit_xnmatkhau->setObjectName(QStringLiteral("lineEdit_xnmatkhau"));

        verticalLayout->addWidget(lineEdit_xnmatkhau);

        lineEdit_mail = new QLineEdit(verticalLayoutWidget);
        lineEdit_mail->setObjectName(QStringLiteral("lineEdit_mail"));

        verticalLayout->addWidget(lineEdit_mail);

        lineEdit_xnmail = new QLineEdit(verticalLayoutWidget);
        lineEdit_xnmail->setObjectName(QStringLiteral("lineEdit_xnmail"));

        verticalLayout->addWidget(lineEdit_xnmail);

        lineEdit_CMND = new QLineEdit(verticalLayoutWidget);
        lineEdit_CMND->setObjectName(QStringLiteral("lineEdit_CMND"));

        verticalLayout->addWidget(lineEdit_CMND);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        comboBox_ngay = new QComboBox(verticalLayoutWidget);
        comboBox_ngay->setObjectName(QStringLiteral("comboBox_ngay"));

        horizontalLayout_2->addWidget(comboBox_ngay);

        comboBox_thang = new QComboBox(verticalLayoutWidget);
        comboBox_thang->setObjectName(QStringLiteral("comboBox_thang"));

        horizontalLayout_2->addWidget(comboBox_thang);

        comboBox_nam = new QComboBox(verticalLayoutWidget);
        comboBox_nam->setObjectName(QStringLiteral("comboBox_nam"));

        horizontalLayout_2->addWidget(comboBox_nam);


        verticalLayout->addLayout(horizontalLayout_2);

        lineEdit_sdt = new QLineEdit(verticalLayoutWidget);
        lineEdit_sdt->setObjectName(QStringLiteral("lineEdit_sdt"));

        verticalLayout->addWidget(lineEdit_sdt);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        comboBox_chucvu = new QComboBox(verticalLayoutWidget);
        comboBox_chucvu->setObjectName(QStringLiteral("comboBox_chucvu"));

        horizontalLayout_3->addWidget(comboBox_chucvu);


        verticalLayout->addLayout(horizontalLayout_3);

        lineEdit_machucvu = new QLineEdit(verticalLayoutWidget);
        lineEdit_machucvu->setObjectName(QStringLiteral("lineEdit_machucvu"));

        verticalLayout->addWidget(lineEdit_machucvu);

        verticalLayoutWidget_2 = new QWidget(dangki);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(210, 20, 161, 371));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(verticalLayoutWidget_2);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout_2->addWidget(label);

        label_10 = new QLabel(verticalLayoutWidget_2);
        label_10->setObjectName(QStringLiteral("label_10"));

        verticalLayout_2->addWidget(label_10);

        label_3 = new QLabel(verticalLayoutWidget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(verticalLayoutWidget_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_2->addWidget(label_4);

        label_14 = new QLabel(verticalLayoutWidget_2);
        label_14->setObjectName(QStringLiteral("label_14"));

        verticalLayout_2->addWidget(label_14);

        label_6 = new QLabel(verticalLayoutWidget_2);
        label_6->setObjectName(QStringLiteral("label_6"));

        verticalLayout_2->addWidget(label_6);

        label_7 = new QLabel(verticalLayoutWidget_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        verticalLayout_2->addWidget(label_7);

        label_8 = new QLabel(verticalLayoutWidget_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout_2->addWidget(label_8);

        label_9 = new QLabel(verticalLayoutWidget_2);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout_2->addWidget(label_9);

        label_5 = new QLabel(verticalLayoutWidget_2);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_2->addWidget(label_5);

        label_2 = new QLabel(verticalLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout_2->addWidget(label_2);

        label_11 = new QLabel(verticalLayoutWidget_2);
        label_11->setObjectName(QStringLiteral("label_11"));

        verticalLayout_2->addWidget(label_11);

        label_12 = new QLabel(verticalLayoutWidget_2);
        label_12->setObjectName(QStringLiteral("label_12"));

        verticalLayout_2->addWidget(label_12);

        label_xnmatkhau = new QLabel(dangki);
        label_xnmatkhau->setObjectName(QStringLiteral("label_xnmatkhau"));
        label_xnmatkhau->setGeometry(QRect(720, 160, 141, 20));
        label_matkhau_1 = new QLabel(dangki);
        label_matkhau_1->setObjectName(QStringLiteral("label_matkhau_1"));
        label_matkhau_1->setGeometry(QRect(724, 110, 141, 20));
        label_mail_1 = new QLabel(dangki);
        label_mail_1->setObjectName(QStringLiteral("label_mail_1"));
        label_mail_1->setGeometry(QRect(724, 220, 111, 20));
        label_tendangnhap_1 = new QLabel(dangki);
        label_tendangnhap_1->setObjectName(QStringLiteral("label_tendangnhap_1"));
        label_tendangnhap_1->setGeometry(QRect(710, 80, 191, 20));

        retranslateUi(dangki);

        QMetaObject::connectSlotsByName(dangki);
    } // setupUi

    void retranslateUi(QDialog *dangki)
    {
        dangki->setWindowTitle(QApplication::translate("dangki", "Dialog", Q_NULLPTR));
        pushButton_dangki->setText(QApplication::translate("dangki", "\304\220\304\203ng k\303\255", Q_NULLPTR));
        radioButton_nam->setText(QApplication::translate("dangki", "Nam", Q_NULLPTR));
        radioButton_nu->setText(QApplication::translate("dangki", "N\341\273\257", Q_NULLPTR));
        label_13->setText(QApplication::translate("dangki", "(M\341\272\255t kh\341\272\251u t\341\273\253 4-12 k\303\255 t\341\273\261)", Q_NULLPTR));
        comboBox_ngay->clear();
        comboBox_ngay->insertItems(0, QStringList()
         << QApplication::translate("dangki", "01", Q_NULLPTR)
         << QApplication::translate("dangki", "02", Q_NULLPTR)
         << QApplication::translate("dangki", "03", Q_NULLPTR)
         << QApplication::translate("dangki", "04", Q_NULLPTR)
         << QApplication::translate("dangki", "05", Q_NULLPTR)
         << QApplication::translate("dangki", "06", Q_NULLPTR)
         << QApplication::translate("dangki", "07", Q_NULLPTR)
         << QApplication::translate("dangki", "08", Q_NULLPTR)
         << QApplication::translate("dangki", "09", Q_NULLPTR)
         << QApplication::translate("dangki", "10", Q_NULLPTR)
         << QApplication::translate("dangki", "11", Q_NULLPTR)
         << QApplication::translate("dangki", "12", Q_NULLPTR)
         << QApplication::translate("dangki", "13", Q_NULLPTR)
         << QApplication::translate("dangki", "14", Q_NULLPTR)
         << QApplication::translate("dangki", "15", Q_NULLPTR)
         << QApplication::translate("dangki", "16", Q_NULLPTR)
         << QApplication::translate("dangki", "17", Q_NULLPTR)
         << QApplication::translate("dangki", "18", Q_NULLPTR)
         << QApplication::translate("dangki", "19", Q_NULLPTR)
         << QApplication::translate("dangki", "20", Q_NULLPTR)
         << QApplication::translate("dangki", "21", Q_NULLPTR)
         << QApplication::translate("dangki", "22", Q_NULLPTR)
         << QApplication::translate("dangki", "23", Q_NULLPTR)
         << QApplication::translate("dangki", "24", Q_NULLPTR)
         << QApplication::translate("dangki", "25", Q_NULLPTR)
         << QApplication::translate("dangki", "26", Q_NULLPTR)
         << QApplication::translate("dangki", "27", Q_NULLPTR)
         << QApplication::translate("dangki", "28", Q_NULLPTR)
         << QApplication::translate("dangki", "29", Q_NULLPTR)
         << QApplication::translate("dangki", "30", Q_NULLPTR)
         << QApplication::translate("dangki", "31", Q_NULLPTR)
        );
        comboBox_thang->clear();
        comboBox_thang->insertItems(0, QStringList()
         << QApplication::translate("dangki", "01", Q_NULLPTR)
         << QApplication::translate("dangki", "02", Q_NULLPTR)
         << QApplication::translate("dangki", "03", Q_NULLPTR)
         << QApplication::translate("dangki", "04", Q_NULLPTR)
         << QApplication::translate("dangki", "05", Q_NULLPTR)
         << QApplication::translate("dangki", "06", Q_NULLPTR)
         << QApplication::translate("dangki", "07", Q_NULLPTR)
         << QApplication::translate("dangki", "08", Q_NULLPTR)
         << QApplication::translate("dangki", "09", Q_NULLPTR)
         << QApplication::translate("dangki", "10", Q_NULLPTR)
         << QApplication::translate("dangki", "11", Q_NULLPTR)
         << QApplication::translate("dangki", "12", Q_NULLPTR)
        );
        comboBox_nam->clear();
        comboBox_nam->insertItems(0, QStringList()
         << QApplication::translate("dangki", "1990", Q_NULLPTR)
         << QApplication::translate("dangki", "1991", Q_NULLPTR)
         << QApplication::translate("dangki", "1992", Q_NULLPTR)
         << QApplication::translate("dangki", "1993", Q_NULLPTR)
         << QApplication::translate("dangki", "1994", Q_NULLPTR)
         << QApplication::translate("dangki", "1995", Q_NULLPTR)
         << QApplication::translate("dangki", "1996", Q_NULLPTR)
         << QApplication::translate("dangki", "1997", Q_NULLPTR)
         << QApplication::translate("dangki", "1998", Q_NULLPTR)
         << QApplication::translate("dangki", "1999", Q_NULLPTR)
        );
        comboBox_chucvu->clear();
        comboBox_chucvu->insertItems(0, QStringList()
         << QApplication::translate("dangki", "Th\303\240nh vi\303\252n", Q_NULLPTR)
         << QApplication::translate("dangki", "Th\341\273\247 th\306\260", Q_NULLPTR)
         << QApplication::translate("dangki", "Admin", Q_NULLPTR)
        );
        label->setText(QApplication::translate("dangki", "H\341\273\215 v\303\240 t\303\252n:", Q_NULLPTR));
        label_10->setText(QApplication::translate("dangki", "Gi\341\273\233i t\303\255nh:", Q_NULLPTR));
        label_3->setText(QApplication::translate("dangki", "T\303\252n \304\221\304\203ng nh\341\272\255p:", Q_NULLPTR));
        label_4->setText(QApplication::translate("dangki", "M\341\272\255t kh\341\272\251u:", Q_NULLPTR));
        label_14->setText(QString());
        label_6->setText(QApplication::translate("dangki", "X\303\241c nh\341\272\255n m\341\272\255t kh\341\272\251u", Q_NULLPTR));
        label_7->setText(QApplication::translate("dangki", "Mail:", Q_NULLPTR));
        label_8->setText(QApplication::translate("dangki", "X\303\241c nh\341\272\255n mail:", Q_NULLPTR));
        label_9->setText(QApplication::translate("dangki", "S\341\273\221 CMND:", Q_NULLPTR));
        label_5->setText(QApplication::translate("dangki", "Ng\303\240y sinh", Q_NULLPTR));
        label_2->setText(QApplication::translate("dangki", "S\341\273\221 \304\221i\341\273\207n tho\341\272\241i:", Q_NULLPTR));
        label_11->setText(QApplication::translate("dangki", "Ch\341\273\251c v\341\273\245 \304\221\304\203ng k\303\255:", Q_NULLPTR));
        label_12->setText(QApplication::translate("dangki", "M\303\243 x\303\241c nh\341\272\255n ch\341\273\251c v\341\273\245:", Q_NULLPTR));
        label_xnmatkhau->setText(QString());
        label_matkhau_1->setText(QString());
        label_mail_1->setText(QString());
        label_tendangnhap_1->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class dangki: public Ui_dangki {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DANGKI_H
