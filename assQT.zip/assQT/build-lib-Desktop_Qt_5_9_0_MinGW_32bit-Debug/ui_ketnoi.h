/********************************************************************************
** Form generated from reading UI file 'ketnoi.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KETNOI_H
#define UI_KETNOI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_ketnoi
{
public:

    void setupUi(QDialog *ketnoi)
    {
        if (ketnoi->objectName().isEmpty())
            ketnoi->setObjectName(QStringLiteral("ketnoi"));
        ketnoi->resize(400, 300);

        retranslateUi(ketnoi);

        QMetaObject::connectSlotsByName(ketnoi);
    } // setupUi

    void retranslateUi(QDialog *ketnoi)
    {
        ketnoi->setWindowTitle(QApplication::translate("ketnoi", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ketnoi: public Ui_ketnoi {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KETNOI_H
