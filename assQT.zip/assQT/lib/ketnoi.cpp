#include "ketnoi.h"
#include "ui_ketnoi.h"

ketnoi::ketnoi(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ketnoi)
{
    ui->setupUi(this);
}

ketnoi::~ketnoi()
{
    delete ui;
}
