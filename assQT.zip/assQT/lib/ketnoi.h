#ifndef KETNOI_H
#define KETNOI_H

#include <QDialog>

namespace Ui {
class ketnoi;
}

class ketnoi : public QDialog
{
    Q_OBJECT

public:
    explicit ketnoi(QWidget *parent = 0);
    ~ketnoi();

private:
    Ui::ketnoi *ui;
};

#endif // KETNOI_H
