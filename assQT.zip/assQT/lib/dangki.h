#ifndef DANGKI_H
#define DANGKI_H

#include <QDialog>
#include <QMessageBox>
#include <QMainWindow>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include <QDebug>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <string>
#include <QString>
#include <QComboBox>
namespace Ui {
class dangki;
}

class dangki : public QDialog
{
    Q_OBJECT

public:
    explicit dangki(QWidget *parent = 0);
    ~dangki();

private slots:


    void on_pushButton_dangki_clicked();


private:
    Ui::dangki *ui;
};

#endif // DANGKI_H
