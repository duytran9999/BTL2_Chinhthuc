#include "dangnhap.h"
#include "ui_dangnhap.h"

dangnhap::dangnhap(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dangnhap)
{
    ui->setupUi(this);
    QSqlDatabase thong_tin=QSqlDatabase::addDatabase("QSQLITE");
    thong_tin.setDatabaseName("D:/tonghop2/assQTthong_tin.sqlite");
    if (!thong_tin.open())
    {
        qDebug()<<"fail";

    }
                else qDebug()<<"good";
}

dangnhap::~dangnhap()
{
    delete ui;
}

void dangnhap::on_pushButton_dangnhap_clicked()
{
    QString tendangnhap,matkhau;
    tendangnhap=ui->lineEdit_tendangnhap->text();
    matkhau=ui->lineEdit_matkhau->text();
    QSqlQuery qry;
    if(qry.exec("select * from thongtinnguoidung where tendangnhap='"+tendangnhap +"' and matkhau='"+matkhau+"'"))
     {
        int count=0;
        while(qry.next())
        {
            count ++;

        }
        if(count==1)  QMessageBox::about(this,"Đăng nhập thành công!","Đăng nhập thành công");
        if(count<1)  QMessageBox::critical(this,"Đăng nhập thất bại!","Tên đăng nhập hoặc mật khẩu sai!");
    }
}
