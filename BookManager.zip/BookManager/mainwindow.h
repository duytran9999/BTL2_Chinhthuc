#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "databaseconnect.h"
#include "addbook.h"
#include "removebook.h"
#include "editbook.h"
#include "findbook.h"
#include "muonsach.h"
#include "trasach.h"
#include "muonquahan.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_actionAbout_Developer_triggered();

    void on_pushButton_2_clicked();     //Thêm sách

    void on_pushButton_4_clicked();     //Xóa sách

    void on_pushButton_3_clicked();     //Chỉnh sửa sách

    void on_pushButton_clicked();       //Tìm sách

    void on_pushButton_5_clicked();     //Mượn sách

    void on_pushButton_6_clicked();     //Trả sách

    void on_pushButton_7_clicked();     //Xử lý trễ hạn

    void on_pushButton_9_clicked();

private:
    Ui::MainWindow *ui;
    FindBook timSach;
    addBook themSach;
    EditBook chinhSua;
    RemoveBook xoaSach;
    MuonSach muonSach;
    TraSach traSach;
    MuonQuaHan muonQuaHan;
};

#endif // MAINWINDOW_H
