#include "editbook.h"
#include "ui_editbook.h"
#include "mainwindow.h"

EditBook::EditBook(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EditBook)
{
    ui->setupUi(this);
}

EditBook::~EditBook()
{
    delete ui;
}

void EditBook::on_pushButton_2_clicked()
{
    this->close();
}

void EditBook::on_pushButton_clicked()
{
    bool isCorrect;

    if(ui->lineEdit->text() == ""){
        QMessageBox::about(this,"Lỗi nhập!","Vui lòng nhập ID sách cần chỉnh sửa!");
    }
    else{
            QSqlQuery editQry;


            if(ui->lineEdit_2->text() == "" && ui->lineEdit_3->text() == "" && ui->lineEdit_4->text() == "" && ui->lineEdit_5->text() == "" && ui->lineEdit_6->text() == "" && ui->lineEdit_7->text() == ""){
                QMessageBox::about(this,"Không được để trống!","Vui lòng nhập giá trị để update!");
            }

            if(ui->lineEdit_7->text()!=""){
              editQry.prepare("update CSBooks set So_luong = :newnumber where ID_sach = :bookid");
              editQry.bindValue(":newnumber",ui->lineEdit_7->text());
              editQry.bindValue(":bookid",ui->lineEdit->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_6->text()!=""){
              editQry.prepare("update CSBooks set Nam = :newyear where ID_sach = :bookid");
              editQry.bindValue(":newyear",ui->lineEdit_6->text());
              editQry.bindValue(":bookid",ui->lineEdit->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_5->text()!=""){
              editQry.prepare("update CSBooks set The_loai = :newkind where ID_sach = :bookid");
              editQry.bindValue(":newkind",ui->lineEdit_5->text());
              editQry.bindValue(":bookid",ui->lineEdit->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_4->text()!=""){
              editQry.prepare("update CSBooks set Tac_gia = :newauthor where ID_sach = :bookid");
              editQry.bindValue(":newauthor",ui->lineEdit_4->text());
              editQry.bindValue(":bookid",ui->lineEdit->text());
              isCorrect = editQry.exec();
            }

            if(ui->lineEdit_3->text()!=""){
              editQry.prepare("update CSBooks set Ten_sach = :newname where ID_sach = :bookid");
              editQry.bindValue(":newname",ui->lineEdit_3->text());
              editQry.bindValue(":bookid",ui->lineEdit->text());
              isCorrect = editQry.exec();
            }

            //ID được cập nhật cuối cùng để không làm sai giá trị bookid được dùng để đối chiếu ở các giá trị update trên
            if(ui->lineEdit_2->text()!=""){
              editQry.prepare("update CSBooks set ID_sach = :newbookid where ID_sach = :bookid");
              editQry.bindValue(":newbookid",ui->lineEdit_2->text());
              editQry.bindValue(":bookid",ui->lineEdit->text());
              isCorrect= editQry.exec();
            }
    }


    if(isCorrect){
        QMessageBox::about(this,"Update thành công","Đã update dữ liệu trong database!");

        //Đưa các dòng nhập về giá trị Null
        ui->lineEdit->setText("");
        ui->lineEdit_2->setText("");
        ui->lineEdit_3->setText("");
        ui->lineEdit_4->setText("");
        ui->lineEdit_5->setText("");
        ui->lineEdit_6->setText("");
        ui->lineEdit_7->setText("");
    }
    else if (ui->lineEdit->text() != ""){
        QMessageBox::about(this,"Lỗi!","Vui lòng kiểm tra lại dữ liệu nhập vào!");
    }

}
