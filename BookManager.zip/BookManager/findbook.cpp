#include "findbook.h"
#include "ui_findbook.h"
#include "mainwindow.h"

FindBook::FindBook(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindBook)
{
    ui->setupUi(this);
}

FindBook::~FindBook()
{
    delete ui;
}

void FindBook::on_pushButton_clicked()
{
    connectDatabase searchDB;
    searchDB.openConnection();

    if(!searchDB.openConnection()){
        QMessageBox::critical(this,"Lỗi Database!","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại.");
    }

    QSqlQuery query;

    //Tìm kiếm dựa trên lựa chọn
    QString str,s2,s3,s4,s5,s6;



    if(ui->lineEdit->text() == ""){
        s2 = "";
    }
    else {
        s2 = "ID_sach like '%" + ui->lineEdit->text() + "%' and ";
    }

    if(ui->lineEdit_2->text() == ""){
        s3 = "";
    }
    else {
        s3 = "Ten_sach like '%" + ui->lineEdit_2->text() + "%' and ";
    }

    if(ui->lineEdit_3->text() == ""){
        s4 = "";
    }
    else {
        s4 = "Tac_gia like '%" + ui->lineEdit_3->text() + "%' and ";
    }

    if(ui->comboBox->currentText() == "Tất cả"){
        s5 = "";
    }
    else {
        s5 = "The_loai = :kind and ";
    }

    if(ui->lineEdit_4->text() == ""){
        s6 = "";
    }
    else {
        s6 = "Nam like '%" + ui->lineEdit_4->text() + "%'";
    }

    str = "select *from CSBooks where " + s2 + s3 + s4 + s5 + s6;

    if (s6 == "")
    {
        str = str.left(str.length() - 5);  //Bỏ chuỗi " and "
    }

    query.exec(str);

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("ID sách"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("Tên sách"));
    databaseModel->setHeaderData(2,Qt::Horizontal,tr("Tác giả"));
    databaseModel->setHeaderData(3,Qt::Horizontal,tr("Thể loại"));
    databaseModel->setHeaderData(4,Qt::Horizontal,tr("Năm xuất bản"));
    databaseModel->setHeaderData(5,Qt::Horizontal,tr("Số lượng"));

    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    searchDB.closeConnection();
}

void FindBook::on_pushButton_2_clicked()
{
    this->close();
}
