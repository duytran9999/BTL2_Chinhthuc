#ifndef MUONSACH_H
#define MUONSACH_H

#include <QWidget>

namespace Ui {
class MuonSach;
}

class MuonSach : public QWidget
{
    Q_OBJECT

public:
    explicit MuonSach(QWidget *parent = 0);
    ~MuonSach();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::MuonSach *ui;
};

#endif // MUONSACH_H
