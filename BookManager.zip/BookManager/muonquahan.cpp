#include "muonquahan.h"
#include "ui_muonquahan.h"
#include "mainwindow.h"

MuonQuaHan::MuonQuaHan(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MuonQuaHan)
{
    ui->setupUi(this);
}

MuonQuaHan::~MuonQuaHan()
{
    delete ui;
}

void MuonQuaHan::on_pushButton_clicked()
{
    QSqlQuery query;
    query.exec("select ID_user,ID_sach,CAST((julianday('now') - julianday(Han_tra)) AS INTEGER) from Muon_sach where julianday('now') - julianday(Han_tra) > 0");

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("ID độc giả"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("ID sách"));
    databaseModel->setHeaderData(2,Qt::Horizontal,tr("Số ngày trễ"));
    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}
