#include "muonsach.h"
#include "ui_muonsach.h"
#include "mainwindow.h"

MuonSach::MuonSach(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MuonSach)
{
    ui->setupUi(this);
}

MuonSach::~MuonSach()
{
    delete ui;
}

void MuonSach::on_pushButton_2_clicked()
{
    //Dua dong nhap ve gia tri null
    ui->lineEdit->setText("");
    ui->lineEdit_2->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");

    this->close();
}

void MuonSach::on_pushButton_clicked()
{
    if(ui->lineEdit->text()=="" || ui->lineEdit_2->text()=="" || ui->lineEdit_3->text()=="" || ui->lineEdit_4->text()=="" ){

            //Kiem tra hang null
            QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else {
        QSqlQuery writeQry;

        writeQry.prepare("insert into Muon_sach (ID_user,ID_sach,Ngay_muon,Han_tra) values(:userid,:bookid,:ngaymuon,:hantra)");
        writeQry.bindValue(":userid",ui->lineEdit->text());
        writeQry.bindValue(":bookid",ui->lineEdit_2->text());
        writeQry.bindValue(":ngaymuon",ui->lineEdit_3->text());
        writeQry.bindValue(":hantra",ui->lineEdit_4->text());


        bool written = writeQry.exec();
        if(written){
            QMessageBox::about(this,"Thêm thành công!","Đã thêm dữ liệu vào liệu vào database.");
            //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
            ui->lineEdit->setText("");
            ui->lineEdit_2->setText("");
            ui->lineEdit_3->setText("");
            ui->lineEdit_4->setText("");

        }
        else{
            QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào và kết nối database  ");
        }

    }
}
