#ifndef EDITBOOK_H
#define EDITBOOK_H

#include <QWidget>

namespace Ui {
class EditBook;
}

class EditBook : public QWidget
{
    Q_OBJECT

public:
    explicit EditBook(QWidget *parent = 0);
    ~EditBook();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::EditBook *ui;
};

#endif // EDITBOOK_H
