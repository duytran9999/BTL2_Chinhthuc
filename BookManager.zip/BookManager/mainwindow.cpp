#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionAbout_Developer_triggered()
{
    QMessageBox::about(this,"LIBPRO software","Created by Xuân Huy");
}

void MainWindow::on_pushButton_2_clicked()
{
    connectDatabase addB;
    addB.openConnection();
    if(!addB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        themSach.show();
    }
}

void MainWindow::on_pushButton_4_clicked()
{
    connectDatabase removeB;
    removeB.openConnection();
    if(!removeB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        xoaSach.show();
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    connectDatabase editB;
    editB.openConnection();
    if(!editB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        chinhSua.show();
    }
}

void MainWindow::on_pushButton_clicked()
{
    connectDatabase findB;
    findB.openConnection();
    if(!findB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        timSach.show();
    }
}

void MainWindow::on_pushButton_5_clicked()
{
    connectDatabase muonS;
    muonS.openConnection();
    if(!muonS.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        muonSach.show();
    }
}

void MainWindow::on_pushButton_6_clicked()
{
    connectDatabase traS;
    traS.openConnection();
    if(!traS.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        traSach.show();
    }
}

void MainWindow::on_pushButton_7_clicked()
{
    connectDatabase muonQ;
    muonQ.openConnection();
    if(!muonQ.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        muonQuaHan.show();
    }
}

void MainWindow::on_pushButton_9_clicked()
{

}
