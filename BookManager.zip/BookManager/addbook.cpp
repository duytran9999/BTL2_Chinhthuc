#include "addbook.h"
#include "ui_addbook.h"
#include "mainwindow.h"

addBook::addBook(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addBook)
{
    ui->setupUi(this);
}

addBook::~addBook()
{
    delete ui;
}

void addBook::on_pushButton_clicked()
{
    if(ui->txt_ID->text()=="" || ui->txt_Bname->text()=="" || ui->txt_Bauthor->text()=="" || ui->txt_Byear->text()=="" || ui->txt_Bkind->text()=="" || ui->txt_Bnumber->text()==""){

            //Kiem tra hang null
            QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else
    {
       //Them du lieu vao database
        QSqlQuery writeQry;

        writeQry.prepare("insert into CSBooks values(:bookid,:name,:author,:kind,:year,:number);");
        writeQry.bindValue(":bookid",ui->txt_ID->text());
        writeQry.bindValue(":name",ui->txt_Bname->text());
        writeQry.bindValue(":author",ui->txt_Bauthor->text());
        writeQry.bindValue(":kind",ui->txt_Bkind->text());
        writeQry.bindValue(":year",ui->txt_Byear->text());
        writeQry.bindValue(":number",ui->txt_Bnumber->text());


        bool written = writeQry.exec();
        if(written){
            QMessageBox::about(this,"Thêm thành công!","Đã thêm dữ liệu vào liệu vào database.");
            //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
            ui->txt_ID->setText("");
            ui->txt_Bname->setText("");
            ui->txt_Bauthor->setText("");
            ui->txt_Bkind->setText("");
            ui->txt_Byear->setText("");
            ui->txt_Bnumber->setText("");
        }
        else{
            QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào và kết nối database  ");
        }


    }

}

void addBook::on_pushButton_2_clicked()
{
    this->close();
}
