#include "dangki.h"
#include "ui_dangki.h"

dangki::dangki(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dangki)
{
    ui->setupUi(this);
}


dangki::~dangki()
{
    delete ui;
}

void dangki::on_pushButton_dangki_clicked()
{
    connectDatabase conn;
    conn.openConnection();

    // Chuẩn bị chuỗi cho câu truy vấn
    QString hoten,tendangnhap,matkhau,xnmatkhau,mail,CMND,sdt,ngay,thang,nam,ngaysinh,gioitinh, chucvu;
    hoten=ui->lineEdit_hoten->text();
    tendangnhap=ui->lineEdit_tendangnhap->text();
    matkhau= ui->lineEdit_matkhau->text();
    xnmatkhau=ui->lineEdit_xnmatkhau->text();
    mail=ui->lineEdit_mail->text();
    CMND=ui->lineEdit_CMND->text();
    sdt= ui->lineEdit_sdt->text();
    ngay= ui->comboBox_ngay->currentText();
    thang= ui->comboBox_thang->currentText();
    nam= ui->comboBox_nam->currentText();
    ngaysinh=ngay+"/"+thang+"/"+nam;
    gioitinh= ui->comboBox->currentText();

    QSqlQuery tkQry;        //Truy vấn cho bảng Tai_khoan
    QSqlQuery ndQry;        //Truy vấn cho bảng Nguoi_dung
    QSqlQuery qry;          //Truy vấn kiểm tra tên đăng nhập
    QSqlQuery vaitro1, vaitro2, vaitro3;
    QSqlQuery taikhoan;


    if(hoten=="" || tendangnhap=="" || matkhau==""|| mail==""||CMND==""||sdt==""||xnmatkhau=="")
    {
        //Kiem tra hang null
        QMessageBox::about(this,"Lỗi nhập dữ liệu!","Không được để trống dữ liệu.");
    }
    else if  (matkhau.size()<4 || matkhau.size()>12 )
    {
         ui->label_matkhau_1->setText("Mật khẩu không hợp lệ. Mật khẩu có độ dài từ 4 đến 12");
    }
    else if(matkhau!=xnmatkhau)
    {
        ui->label_xnmatkhau->setText("Mật khẩu xác nhận sai");
    }
    else if(!ui->radioButton->isChecked() && !ui->radioButton_2->isChecked() && !ui->radioButton_3->isChecked())
    {
        ui->label_Chucvu->setText("Phải chọn ít nhất 1 ô");
    }
    else if(qry.exec("select * from Tai_khoan where Ten_dang_nhap='"+tendangnhap +"'"))
    {
        int count=0;
        while(qry.next())
        {
            count ++;
        }
        if(count==1)  ui->label_tendangnhap_1->setText("Tên đăng nhập đã được sử dụng");
        else
           {

               taikhoan.exec("insert into NguoiDung_TK values ('"+tendangnhap+"','"+CMND+"')");

               ndQry.prepare("insert into Nguoi_dung values ('"+hoten+"','"+gioitinh+"','"+CMND+"','"+ngaysinh+"','"+mail+"','"+sdt+"')");
               bool written1 = ndQry.exec();

               tkQry.prepare("insert into Tai_khoan(Ten_dang_nhap,Mat_khau) values ('"+tendangnhap+"','"+matkhau+"')");
               bool written2 =tkQry.exec();

               if(ui->radioButton->isChecked())
               {
                   vaitro1.exec("insert into Taikhoan_Vaitro values ('"+tendangnhap+"','Độc giả')");
               }
               if(ui->radioButton_2->isChecked())
               {
                   vaitro2.exec("insert into Taikhoan_Vaitro values ('"+tendangnhap+"','Thủ thư')");
               }
               if(ui->radioButton_3->isChecked())
               {
                   vaitro3.exec("insert into Taikhoan_Vaitro values ('"+tendangnhap+"','Quản lý')");
               }


               if(written1 && written2 )
               {
                   QMessageBox::about(this,"Đăng kí thành công!","Vui lòng chờ quản lý phê duyệt");
               }
               else
               {
                   QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào và kết nối database  ");
               }
             //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
             //  ui->lineEdit_hoten->setText("");
             //  ui->lineEdit_tendangnhap->setText("");
             //  ui->lineEdit_matkhau->setText("");
              // ui->lineEdit_mail->setText("");
              // ui->lineEdit_CMND->setText("");
             //  ui->lineEdit_sdt->setText("");
             //  ui->lineEdit_xnmatkhau->setText("");
             //  ui->lineEdit_xnmail->setText("");
             //  ui->lineEdit_machucvu->setText("");
             //  ui->label_matkhau_1->setText("");
             //  ui->label_xnmatkhau->setText("");
             //  ui->label_mail_1->setText("");
             //  ui->label_tendangnhap_1->setText("");
            }
    }
}


void dangki::on_pushButton_clicked()
{
    this->hide();
}
