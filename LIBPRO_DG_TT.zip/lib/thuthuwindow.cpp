#include "thuthuwindow.h"
#include "ui_thuthuwindow.h"
#include "chonchucnang.h"

ThuThuWindow::ThuThuWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ThuThuWindow)
{
    ui->setupUi(this);
}

ThuThuWindow::~ThuThuWindow()
{
    delete ui;
}

void ThuThuWindow::on_pushButton_2_clicked()
{
    connectDatabase addB;
    addB.openConnection();
    if(!addB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        themSach.show();
    }
}

void ThuThuWindow::on_pushButton_4_clicked()
{
    connectDatabase removeB;
    removeB.openConnection();
    if(!removeB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        xoaSach.show();
    }
}

void ThuThuWindow::on_pushButton_3_clicked()
{
    connectDatabase editB;
    editB.openConnection();
    if(!editB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        chinhSua.show();
    }
}

void ThuThuWindow::on_pushButton_clicked()
{
    connectDatabase findB;
    findB.openConnection();
    if(!findB.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        timSach.show();
    }
}

void ThuThuWindow::on_pushButton_5_clicked()
{
    connectDatabase muonS;
    muonS.openConnection();
    if(!muonS.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        muonSach.setthuThuID_MS(thuThuID);
        muonSach.show();
    }
}

void ThuThuWindow::on_pushButton_6_clicked()
{
    connectDatabase traS;
    traS.openConnection();
    if(!traS.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        traSach.show();
    }
}

void ThuThuWindow::on_pushButton_7_clicked()
{
    connectDatabase muonQ;
    muonQ.openConnection();
    if(!muonQ.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        muonQuaHan.show();
    }
}

void ThuThuWindow::on_pushButton_8_clicked()
{
    this->close();

}

void ThuThuWindow::on_pushButton_10_clicked()
{
    connectDatabase conn;
    conn.openConnection();
    if(!conn.openConnection())
    {
        QMessageBox::critical(this,"Lỗi kết nối","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại");
    }
    else
    {
        this->close();
        ChonChucNang *chonCN = new ChonChucNang;
        chonCN->settendangnhap_CN(thuThuID);
        chonCN->show();
    }
}

void ThuThuWindow::on_pushButton_9_clicked()
{
    thongBao.show();
}

void ThuThuWindow::on_pushButton_12_clicked()
{
    doiMK.settendangnhap(thuThuID);
    doiMK.show();
}
