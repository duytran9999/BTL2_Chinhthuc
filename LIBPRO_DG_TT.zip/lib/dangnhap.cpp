#include "dangnhap.h"
#include "ui_dangnhap.h"

dangnhap::dangnhap(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dangnhap)
{
    ui->setupUi(this);
}

dangnhap::~dangnhap()
{
    delete ui;
}

void dangnhap::on_pushButton_dangnhap_clicked()
{
    connectDatabase conn;
    conn.openConnection();
    if(!conn.openConnection()){
        QMessageBox::critical(this,"Lỗi Database!","Không thể kết nối với Database! Vui lòng kiểm tra Database và thử lại.");
    }

    QString tendangnhap,matkhau;
    tendangnhap=ui->lineEdit_tendangnhap->text();
    matkhau=ui->lineEdit_matkhau->text();
    QSqlQuery qry;

    if(qry.exec("select * from Tai_khoan where Ten_dang_nhap='"+tendangnhap +"' and Mat_khau='"+matkhau+"' and Tinh_trang = 1" ))
     {
        int count=0;
        while(qry.next())
        {
            count ++;

        }
        if(count==1)  {
            //QMessageBox::about(this,"Đăng nhập thành công!","Đăng nhập thành công");
            this->hide();
            chonCN.settendangnhap_CN(tendangnhap);
            chonCN.show();

        }
        if(count<1)  QMessageBox::critical(this,"Đăng nhập thất bại!","Tên đăng nhập, mật khẩu sai hoặc tài khoản đã bị khóa!");
        if(count>1)  QMessageBox::critical(this,"Lỗi Database!","Vui lòng kiểm tra lại Database và thử lại.");

    }
}
