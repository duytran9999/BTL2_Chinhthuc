#include "tt_tbchung.h"
#include "ui_tt_tbchung.h"

TT_TBChung::TT_TBChung(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TT_TBChung)
{
    ui->setupUi(this);
}

TT_TBChung::~TT_TBChung()
{
    delete ui;
}

void TT_TBChung::on_pushButton_clicked()
{
    QSqlQuery qry;
    qry.prepare("insert into Thong_bao_chung values (:thongbao)");
    qry.bindValue(":thongbao",ui->textEdit->toPlainText());
    bool written = qry.exec();
    if(written){
        QMessageBox::about(this,"Thành công!","Đã gửi thông báo đến mọi người.");
        //Dua dong nhap ve gia tri null de cho phep nhap gia tri moi
        ui->textEdit->setText("");
    }
    else{
        QMessageBox::critical(this,"Lỗi!","Vui lòng kiểm tra dữ liệu nhập vào và kết nối database  ");
    }

}
