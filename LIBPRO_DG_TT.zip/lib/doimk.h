#ifndef DOIMK_H
#define DOIMK_H

#include <QWidget>
#include "databaseconnect.h"

namespace Ui {
class DoiMK;
}

class DoiMK : public QWidget
{
    Q_OBJECT

public:
    explicit DoiMK(QWidget *parent = 0);
    ~DoiMK();
    void settendangnhap(QString str)
    {
        tendangnhap = str;
    }

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::DoiMK *ui;
    QString tendangnhap;
};

#endif // DOIMK_H
