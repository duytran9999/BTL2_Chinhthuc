#ifndef TT_TBCHUNG_H
#define TT_TBCHUNG_H

#include <QWidget>
#include "databaseconnect.h"

namespace Ui {
class TT_TBChung;
}

class TT_TBChung : public QWidget
{
    Q_OBJECT

public:
    explicit TT_TBChung(QWidget *parent = 0);
    ~TT_TBChung();

private slots:
    void on_pushButton_clicked();

private:
    Ui::TT_TBChung *ui;
};

#endif // TT_TBCHUNG_H
