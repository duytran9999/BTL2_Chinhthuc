#include "trangchu.h"
#include "ui_trangchu.h"

trangchu::trangchu(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::trangchu)
{
    ui->setupUi(this);

}

trangchu::~trangchu()
{
    delete ui;
}

void trangchu::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent( event );

    //Kết nối database
    connectDatabase conn;
    conn.openConnection();

    //Bảng thông báo
    QSqlQuery query;
    query.exec("select * from Thong_bao_chung");
    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->horizontalHeader()->hide();

    //Bảng sách mới
    QSqlQuery query1;
    query1.exec("select * from CSBooks where Nam = (select MAX(Nam) from CSBooks)");
    QSqlQueryModel* databaseModel1 = new QSqlQueryModel;
    databaseModel1->setQuery(query1);
    databaseModel1->setHeaderData(0,Qt::Horizontal,tr("ID sách"));
    databaseModel1->setHeaderData(1,Qt::Horizontal,tr("Tên sách"));
    databaseModel1->setHeaderData(2,Qt::Horizontal,tr("Tác giả"));
    databaseModel1->setHeaderData(3,Qt::Horizontal,tr("Thể loại"));
    databaseModel1->setHeaderData(4,Qt::Horizontal,tr("Năm xuất bản"));
    databaseModel1->setHeaderData(5,Qt::Horizontal,tr("Số lượng"));

    ui->tableView_2->setModel(databaseModel1);
    ui->tableView_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    //Số lượng thành viên
    QSqlQuery query2;
    query2.exec("select COUNT(*) from Nguoi_dung");
    QSqlQueryModel* model = new QSqlQueryModel;
    model->setQuery(query2);
    ui->listView->setModel(model);
}

void trangchu::on_pushButton_2_clicked()
{
    dang_ki=new dangki(this);
    dang_ki->show();
}

void trangchu::on_pushButton_3_clicked()
{
    this->hide();
    dang_nhap=new dangnhap(this);
    dang_nhap->show();
}

void trangchu::on_timsach_clicked()
{
    timS.show();
}

