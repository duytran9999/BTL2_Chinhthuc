#ifndef DG_TRASACH_H
#define DG_TRASACH_H

#include <QWidget>

namespace Ui {
class DG_TraSach;
}

class DG_TraSach : public QWidget
{
    Q_OBJECT

public:
    explicit DG_TraSach(QWidget *parent = 0);
    ~DG_TraSach();
    void setdocgiaID_PM(QString str)
    {
        docgiaID_PM = str;
    }

private slots:
    void showEvent(QShowEvent *event);


private:
    Ui::DG_TraSach *ui;
    QString docgiaID_PM;
};

#endif // DG_TRASACH_H
