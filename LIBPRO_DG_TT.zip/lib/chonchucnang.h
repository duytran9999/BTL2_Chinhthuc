#ifndef CHONCHUCNANG_H
#define CHONCHUCNANG_H

#include <QWidget>
#include "databaseconnect.h"
#include "thuthuwindow.h"
#include "docgia.h"

namespace Ui {
class ChonChucNang;
}

class ChonChucNang : public QWidget
{
    Q_OBJECT

public:
    explicit ChonChucNang(QWidget *parent = 0);
    ~ChonChucNang();
    void settendangnhap_CN(QString str)
    {
        tendangnhap_CN = str;
    }



private slots:
    void showEvent(QShowEvent *event);

    void on_pushButton_clicked();

private:
    Ui::ChonChucNang *ui;
    QString tendangnhap_CN;
    DocGia docGia;
    ThuThuWindow thuThu;
};

#endif // CHONCHUCNANG_H
