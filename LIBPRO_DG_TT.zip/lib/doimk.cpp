#include "doimk.h"
#include "ui_doimk.h"

DoiMK::DoiMK(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DoiMK)
{
    ui->setupUi(this);
}

DoiMK::~DoiMK()
{
    delete ui;
}

void DoiMK::on_pushButton_clicked()
{
    QSqlQuery qry;
    qry.exec("select * from Tai_khoan where Ten_dang_nhap='"+tendangnhap +"' and Mat_khau='"+ui->lineEdit->text()+"'" );
    int count=0;
    while(qry.next())
    {
        count ++;
    }
    if(count!=1)
        QMessageBox::critical(this,"Thất bại","Nhập sai mật khẩu hiện tại");
    else if(ui->lineEdit_2->text() != ui->lineEdit_3->text())
        QMessageBox::critical(this,"Thất bại","Mật khẩu xác nhận không giống mật khẩu mới");
    else
    {
        qry.exec("update Tai_khoan set Mat_khau = '"+ui->lineEdit_2->text()+"' where Ten_dang_nhap ='"+tendangnhap +"'" );
        QMessageBox::about(this,"Thành công","Tài khoản đã được đổi mật khẩu");
        this->close();
    }
}

void DoiMK::on_pushButton_2_clicked()
{
    this->close();
}
