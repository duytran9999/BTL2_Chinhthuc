#include "dg_phieumuon.h"
#include "ui_dg_phieumuon.h"
#include "docgia.h"

DG_TraSach::DG_TraSach(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DG_TraSach)
{
    ui->setupUi(this);
}

DG_TraSach::~DG_TraSach()
{
    delete ui;
}

void DG_TraSach::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    QSqlQuery query;
    query.exec("select ID_phieu_muon,ID_sach,So_luong,Ngay_muon,Cho_phep,ID_thuthu,Ngay_tra from Muon_sach where ID_user = '"+docgiaID_PM+"'");

    //Xuất các giá trị ra Table View
    QSqlQueryModel* databaseModel = new QSqlQueryModel;
    databaseModel->setQuery(query);
    databaseModel->setHeaderData(0,Qt::Horizontal,tr("ID phiếu mượn"));
    databaseModel->setHeaderData(1,Qt::Horizontal,tr("ID sách"));
    databaseModel->setHeaderData(2,Qt::Horizontal,tr("Số lượng"));
    databaseModel->setHeaderData(3,Qt::Horizontal,tr("Ngày phê duyệt"));
    databaseModel->setHeaderData(4,Qt::Horizontal,tr("Phê duyệt"));
    databaseModel->setHeaderData(5,Qt::Horizontal,tr("ID thủ thư"));
    databaseModel->setHeaderData(6,Qt::Horizontal,tr("Ngày trả"));
    ui->tableView->setModel(databaseModel);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}
